import re
# 设置全局下标变量，用于定义第四个逗号的下标位置
f = list(open("C:\\Users\\qw\\Desktop\\实践小项目\\shsq-mini.txt", "r", encoding="UTF-8"))  # 按列读取
f1 = open('part_1.txt', 'w+', encoding='UTF-8')  # 第一部分
f2 = open('part_2.txt', 'w+', encoding='UTF-8')  # 第二部分
f3 = open('part_3.txt', 'w+', encoding='UTF-8')  # 第三部分


def one_row(start, end, group):
    for i2 in range(start+1, end-1):
        f2.write(group[i2])
    f2.write('\n')


for i in f:  # 循环遍历每一列，进行字符串的匹配
    four_index = -1
    if re.match('10000', i):  # 匹配成功,也就是说，作为新一条投诉的开始，那我们就在这一行进行末尾的匹配，也就是查看是否是为同一行。
        sum = 0
        for ch in i:
            if ch != ',':
                four_index += 1
                f1.write(ch)
                continue
            elif ch == ',':
                four_index += 1
                sum += 1
                if sum == 4:
                    f1.write('\n')
                    break
                else:
                    f1.write(' ')
        if re.search(',0.0,0.0,', i):  # 判断是否是同一行,是的话，那就输出后面的part_3
            m = re.search(',0.0,0.0,', i)
            Start = m.start()+1
            one_row(four_index, Start, i)
            for index in range(Start, len(i)):
                if i[index] == ',':
                    f3.write(' ')
                else:
                    f3.write(i[index])
        else:  # 不是同一行
            for xx in range(four_index+1, len(i)):
                f2.write(i[xx])
            continue
    # 也就是说，我们寻找的投诉内容已经是多行，假设这里是三行，这是第二行，那么就要分情况讨论了。
    # 判断结束的标志是否在这一行，不在的话，那就直接输出，在的话，找到下标，输出前面的内容。
    # 下面，我们判断第一种情况，也即结束的标志不在本行。
    # 判断结束的条件在不在本行的代码
    else:
        if re.search(',0.0,0.0,', i):  # 也就是，存在结束标志
            m = re.search(',0.0,0.0,', i)
            Start = m.start()+1
            for index in range(Start, len(i)):
                if i[index] == ',':
                    f3.write(' ')
                else:
                    f3.write(i[index])
            for index in range(Start-1):
                f2.write(i[index])
            f2.write('\n')
        else:
            f2.write(i)
f1.close()
f2.close()
f3.close()



