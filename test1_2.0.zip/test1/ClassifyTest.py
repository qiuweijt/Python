import re
import xlrd  # 表格操作

part1_path = 'part_1.txt'
part4_path = 'part4.txt'
part5_path = 'part5.txt'
excel_path = 'work_book.xlsx'
p1 = list(open(part1_path, 'r+', encoding='UTF-8'))
p4 = list(open(part4_path, 'r+', encoding='UTF-8'))
p5 = open(part5_path, 'w+', encoding='UTF-8')
one_classify = open('one_classify.txt', 'w+', encoding="UTF-8")
two_classify = open('two_classify.txt', 'w+', encoding="UTF-8")
three_classify = open('three_classify.txt', 'w+', encoding="UTF-8")
one_column = open("one_column.txt", 'w+', encoding="UTF-8")
two_column = open("two_column.txt", 'w+', encoding="UTF-8")
three_column = open("three_column.txt", 'w+', encoding="UTF-8")
mark2 = open("mark2.txt",'w+',encoding="UTF-8")
data = xlrd.open_workbook(excel_path)
table = data.sheet_by_name('工作表1')

# 获取三列数据
one_ncol_value = table.col_values(0)
two_ncol_value = table.col_values(1)
three_ncol_value = table.col_values(2)


# 筛选表格数据,确认字符是否为数字
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass
    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass
    return False


# 去除表格除类型之外的内容
def check(message):
    dat = []
    for a in range(2, len(message)):
        cells = message[a]
        if cells == '':
            continue
        for ch in range(0, len(cells)):
            mes = cells[ch]
            if is_number(mes):
                break
            if mes == '\n':
                break
        dat.append(cells[:ch])
    return dat


# 去除表格数据的数字和回车
def delete_num(message):
    dat = []
    for a in range(2, len(message)):
        cells = message[a]
        for ch in range(0, len(cells)):
            mes = cells[ch]
            if is_number(mes):
                break
            if mes == '\n':
                break
        dat.append(cells[:ch])
    return dat


def delete_two_col(message):
    dat = []
    for a in range(2, len(message)):
        dat.append(message[a])
    return dat


# 筛选part1中的类型
def check_out(p1):
    dat = []
    message = []
    for i in p1:
        index = 0
        space = 0
        if re.search(']', i):
            for ch in i:
              index += 1
              if ch == ']':
                  break
            dat.append(i[index:len(i)])
        else:
            for ch in i:
                index += 1
                if ch == ' ':
                    space += 1
                    if space == 3:
                        break
            dat.append(i[index:len(i)])
    for mes in dat:
        for n in range(1, len(mes)):
            if mes[n] == '\n':
                break
        message.append(mes[:n])
    return message


# 初步分类中的比较函数，逐字比较：返回a中与b的元素相同的汉字占b比重最大的元素
def compare_obt(b, a):
    idx = []
    for i in range(len(b)):
        j = 0
        for x in a:
            y = b[i]
            for z in y:
                if x == z:
                    j += 1
                    break
        p = j/len(b[i])
        idx.append(p)
    n = idx.index(max(idx))
    return b[n]


#  返回最大的占比
def compare_pct(b, a):
    idx = []
    for i in range(len(b)):
        j = 0
        for x in a:
            y = b[i]
            for z in y:
                if x == z:
                    j += 1
                    break
        p = j/len(b[i])
        idx.append(p)
    n = max(idx)
    return n


one_col = check(one_ncol_value)
two_col = check(two_ncol_value)
one_col_no_num = delete_num(one_ncol_value)
two_col_no_num = delete_num(two_ncol_value)
three_col_no_num = delete_two_col(three_ncol_value)


#   输出三级列表个数关系
def number(mes, mark):
    m = 1
    for n in range(1, len(mes)):
        if mes[n] == '':
            m += 1
        elif mes[n] != '':
            mark.write(str(m) + ',')
            m += 1
        if n == len(mes)-1:
            mark.write(str(m))


number(two_col_no_num, mark2)


for i in one_col:
    one_column.write(i + '\n')
for i in two_col:
    two_column.write(i + '\n')
for i in three_col_no_num:
    three_column.write(i + '\n')

mes = check_out(p1)
p1_mes = list(map(lambda x: x.strip(), p1))
for i in range(len(mes)):
    if compare_pct(one_col, mes[i]) > compare_pct(two_col, mes[i]) and compare_pct(one_col, mes[i]) > \
            compare_pct(three_col_no_num, mes[i]):
        message = compare_obt(one_col, mes[i])
        p5.write(p1_mes[i] + '- - - -' + message + '-\n')
        one_classify.write(message + '\n')
        two_classify.write('-\n')
        three_classify.write('-\n')
    elif compare_pct(two_col, mes[i]) >= compare_pct(one_col, mes[i]) and compare_pct(two_col, mes[i]) > \
            compare_pct(three_col_no_num, mes[i]) and compare_pct(two_col, mes[i]) != 0:
        message = compare_obt(two_col, mes[i])
        j = two_col_no_num.index(message)
        while one_col_no_num[j] == '':
            j -= 1
        p5.write(p1_mes[i] + '- - - -' + one_col_no_num[j] + '--' + message + '\n')
        one_classify.write(one_col_no_num[j] + '\n')
        two_classify.write(message + '\n')
        three_classify.write('-\n')
    elif compare_pct(three_col_no_num, mes[i]) >= compare_pct(one_col, mes[i]) and compare_pct(two_col,mes[i]) \
            <= compare_pct(three_col_no_num, mes[i]) != 0:
        message = compare_obt(three_col_no_num, mes[i])
        n = three_col_no_num.index(message)
        j = n
        k = n
        while one_col_no_num[j] == '':
            j -= 1
        while two_col_no_num[k] == '':
            k -= 1
        p5.write(p1_mes[i] + '- - - -' + one_col_no_num[j] + '--' + two_col_no_num[k] + '--' + message + '\n')
        one_classify.write(one_col_no_num[j] + '\n')
        two_classify.write(two_col_no_num[k] + '\n')
        three_classify.write(message + '\n')
    else:
        p5.write(p1_mes[i] + '- - - -' + '其他-\n')
        one_classify.write('其他\n')
        two_classify.write('-\n')
        three_classify.write('-\n')
p5.close()
