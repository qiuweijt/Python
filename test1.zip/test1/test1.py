import xlrd
# message = "Hello Python"
# first_name = "qiu"
# last_name = "wei"
# a = 3
# number = [31, 22, 13]
# # python3 “/” 号可以直接得到小数
#
# # 幂次
# age = 3**3
# full_name = first_name + " " + last_name + " " + "is" + " " + str(age) + " " + "years old!"
# print(full_name.rstrip())
#
# # 首字母大写
# print(message.title())
#
# # "sort()"方法可对数组永久排序，改变原始长度；“sorted()”临时改变长度
# number.sort()
# print(number)
#
# # 数组长度
# print(len(number))
#
# # for循环使用，循环缩进的内容
# for num in number:
#     print("this is" + " " + str(num) + "\n")
# print("这个就不会循环，没有缩进")
#
# for value in range(1, 5):
#     print(value)
# numbers = list(range(1, 9))
# print(numbers)
# for n in numbers[:6]:
#     print(n)
#
# # 输出最小值
#
# print("最小值为：" + str(min(numbers)))
#
# # 元组
# dimensions = (20, 30)
# for dimension in dimensions:
#     print(dimension)
#
# dimensions = (30, 40)
# for dimension in dimensions:
#     print(dimension)
#
# # if语句
# numbers = list(range(1, 9))
# for number in numbers:
#     if number == 5:
#         print("第" + str(number) + "个数是5")
#     else:
#         print("第" + str(number) + "个数不是5")
#
# car = 'bmw'
# if car == 'bmw' or car == 'bwm':
#     print(car)
#
# numbers = list(range(1,5))
# number = 5
# if number not in numbers:
#     print(numbers)
#     print(str(number) + '不在number中')
#
# # 字典，类似对象
# man = {
#     'color': 'white',
#     'age': 22,
#     'sex': 'woman'
# }
# print(man['sex'])
# print(man['color'])
# print(man['age'])
#
# # 添加,修改，删除字典键值对，故可直接创建一个新的空的字典，如:man{}
#
# # 修改
# man['color'] = 'yellow'
# man['age'] = 23
# print(man)
#
# # 删除
# del man['color']
# del man['age']
# print(man)
#
# # 添加
# man['profession'] = 'math'
# man['color'] = 'yellow'
# man['age'] = '22'
# print(man)
#
# # 遍历字典
# for key, value in man.items():
#     print("'" + key + "' : '" + value + "'")
#
# i = 0
# for key, value in man.items():
#     i = i + 1
#     print('\nkey = ' + key)
#     print('value = ' + value)
#     print(i)
#
# # 只输出键
# for name in man.keys():
#     print('\n' + name.title())
#
# for name in man.values():
#     print('\n' + name.title())
#
# # 排序
# for name in sorted(man.keys()):
#     print(name.title())
#
# # 剔除重复元素
# man['family'] = 'woman'
# print("\n" + str(man) + '\n')
# for name in set(man.values()):
#     print(name)
#
# # 字典中的键嵌套多个值时，需要使用列表
# man['family'] = ['Dad', 'Mom', 'Sister']
# print(man['family'])
# print(man)
#
# # 输入
# # 猜字游戏
# # n = 30
# # m = input("I have a number and can you guess it?\nPlease input your number: ")
# # m = int(m)
# # print('Your number is : ' + str(m))
# # if m == n:
# #     print('Good!\n You are right!')
# # elif m > n:
# #     print('too high!')
# # else:
# #     print('too low!')
#
# # break的运用
# numbers = list(range(1, 9))
# for number in numbers:
#     print(number)
#     if number == 6:
#         break
# print('\n')
#
# # while
# numbers = list(range(1, 9))
# while 1 in numbers:
#     print('1在数组中')
#     numbers.remove(1)
#     del numbers[0]
#     break
# print(numbers)
#
#
# def hello_user(Name):
#     print(Name + '你好！')
#
#
# name = '邱伟'
# hello_user(name)
#
#
# # def hello_man(f_name, l_name):
# #     person = f_name + ' ' + l_name
# #     return person.title()
# #
# #
# # print('Please input your name')
# # f_name = input('first name : ')
# # l_name = input('last name : ')
# # person = hello_man(f_name, l_name)
# # print('Hello ' + person + '!')
#
#
# # 输入任意数量的参数
# def make_pizza(*toppings):
#     print('Making a pizza need follow toppings:')
#     for topping in toppings:
#         print('-' + topping)
#
#
# make_pizza('peperoni')
# make_pizza('green pepper', 'cheese', 'mushrooms')
#
# # 类和实例
# class Person:
#     def __init__(self, name, age, sex):
#         self.name = name
#         self.age = age
#         self.sex = sex
#
#     def get_name(self):
#         return self.name.title()
#
#     def get_age(self):
#         return self.age
#
#     def get_sex(self):
#         return self.sex
#
#     def get_full_description(self):
#         full_description = "姓名：" + self.name.title() + "\n年龄：" + str(self.age) + "\n性别：" + self.sex
#         return full_description
#
# # 修改属性:通过添加方法
#     def update_age(self, age):
#         self.age = age
#
#
# person = Person('jin tong', 22, 'woman')
# print(person.get_name())
# print(person.get_age())
# print(person.get_sex())
# print(person.get_full_description())
#
# # 添加方法
# person.update_age(23)
# print(person.get_full_description())
#
# # 直接修改属性
# person.age = 24
# print(person.get_full_description())
#
#
# # 继承
# class Son_class(Person):
#     def __init__(self, name, age, sex):
#         super().__init__(name, age, sex)
#
#
# woman = Son_class('qiu qian', 27, 'woman')
# print(woman.get_full_description())


# 文件操作
# 读文件
# file_path = 'C:\\Users\\qw\\Desktop\\test.txt'
# with open(file_path) as file_object:
#     file_message = file_object.read()
#     print(file_message.title().rstrip())
#
# with open(file_path) as file_object:
#     lines = file_object.readlines()
#     for line in lines:
#         print(line.rstrip())
#
# with open(file_path) as file_object:
#     lines = file_object.readlines()
#
# message = ''
# for line in lines:
#    message += line.rstrip()
#
# print(message)
# print(len(message))
#
# # 写入文件
# file_name = 'C:\\Users\\qw\\Desktop\\Pythontest.txt'
# with open(file_name, 'w') as file_object:
#     file_object.write('I love Python!')

# 异常处理
# print("Please input two number and input 'q' to quit:")
# while True:
#     number1 = input("Input number1:")
#     if number1 == 'q':
#         break
#     number2 = input("Input number2:")
#     if number2 == 'q':
#         break
#     try:
#         answer = int(number1)/int(number2)
#     except ZeroDivisionError:
#         print("You can't divide 0!")
#     else:
#         print(answer)

# 文本分析
# split()分割字符串，并存储在一个列表中
# message = "hello Python"
# print(message.split())
# print(len(message.split()))

# 计算文件的字数
# try:
#     file_path = "C:\\Users\\qw\\Desktop\\example.txt"
#     with open(file_path) as file_object:
#         message = file_object.read()
# except FileNotFoundError:
#     print("This file doesn't exist!")
# else:
#     print(len(message.split()))

# list()
# file_path = "C:\\Users\\qw\\Desktop\\test.txt"
# message = list(open(file_path, "r+", encoding="UTF-8"))
# f2 = open("C:\\Users\\qw\\Desktop\\test1.txt", "w+", encoding="UTF-8")
# print(message)
# for ch in message:
#     for i in ch:
#         if i == '\n':
#             break
#         f2.write(i)

# 查看Excel
# data = xlrd.open_workbook("C:\\Users\\qw\\Desktop\\test.xls")
# 查看工作表
# print("sheets：" + str(data.sheet_names()))

# 通过文件名获得工作表,获取工作表1
# table = data.sheet_by_name('工作表1')

# # 打印data.sheet_names()可发现，返回的值为一个列表，通过对列表索引操作获得工作表1
# # table = data.sheet_by_index(0)
#
# # 获取行数和列数
# # 行数：table.nrows
# # 列数：table.ncols
# print("总行数：" + str(table.nrows))
# print("总列数：" + str(table.ncols))
#
# # 获取整行的值 和整列的值，返回的结果为数组
# # 整行值：table.row_values(start,end)
# # 整列值：table.col_values(start,end)
# # 参数 start 为从第几个开始打印，
# # end为打印到那个位置结束，默认为none
# print("整行值：" + str(table.row_values(0)))
# print("整列值：" + str(table.col_values(1)))
#
# # 获取某个单元格的值，例如获取B3单元格值
# cel_B3 = table.cell(0, 1).value
# print("第一行第二列的值：" + cel_B3)

# m = 0
# print(table.ncols)
# for i in range(0, table.nrows):
#     m += 1
#     n = 0
#     for j in range(0, table.ncols):
#         n += 1
#         print('第%d' % m + '行,第%d' % n + '列' + table.cell(i, j).value)

def in_it(a, b):
    idx = []
    for i in range(len(b)):
        j = 0
        for x in a:
            y = b[i]
            for z in y:
                if x == z:
                    j += 1
                    break
        idx.append(j)
    n = idx.index(max(idx))
    if max(idx) != 0:
        return n
    else:
        return -1


x = 'abcde'
y = ['assss','abcdx', 'y', 'g', 'w']
print(in_it(x, y))
# print(len(y))
# for z in x:
#     print(z)
# for i in range(3):
#     print(i)


# mm = [2, 3, 4, 5, 6, 3, 7, 8]
# n = mm.index(max(mm))
# print(n)
# print(mm)

