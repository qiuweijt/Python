import xlrd
import re
# excel_path = "work_book.xlsx"
# data = xlrd.open_workbook(excel_path)
# table = data.sheet_by_name('工作表1')
# print("行数：%d" % table.nrows + "\n列数：%d" % table.ncols)

word_path = "part_1.txt"
p1 = list(open(word_path, 'r', encoding='UTF-8'))  # 将part1内容存入列表
p4 = open('part4.txt', 'w+', encoding='UTF-8')  # 将类型存入新的文件part4.txt
p6 = open('part6.txt', 'w+', encoding="UTF-8")

# 筛选类型
for i in p1:
    index = -1
    space = 0
    if re.search(']', i):
        for ch in i:
          index += 1
          if ch == ']':
              break
        for n in range(index+1, len(i)):
            p4.write(i[n])
    else:
        for ch in i:
            index += 1
            if ch == ' ':
                space += 1
                if space == 3:
                    break
        for n in range(index+1, len(i)):
            p4.write(i[n])

for i in p1:
    index = -1
    space = 0
    for ch in i:
        index += 1
        if ch == ' ':
            space += 1
            if space == 3:
                break
    for n in range(index):
            p6.write(i[n])
    p6.write('\n')
p4.close()
p6.close()















